sap.ui.define([
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"nw/epm/refapps/purchaseorders/approve/controller/BaseController",
	"nw/epm/refapps/purchaseorders/approve/controller/SubControllerForApproval",
	"nw/epm/refapps/purchaseorders/approve/model/utilities",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Device, JSONModel, BaseController, SubControllerForApproval, utilities, Filter, FilterOperator) {
	"use strict";

	// The detail screen displaying a purchase order
	return BaseController.extend("nw.epm.refapps.purchaseorders.approve.controller.S3_PurchaseOrderDetails", {
		// attributes set during initialization:
		// _oApplication: controller of the app
		// _oItemsTable: control displaying the PO items
		// _oItemTemplate: template for the column structure of the table
		// _oViewModel: JSON model containing properties used in declarative binding
		// _oSubControllerForApproval: Helper class dealing with approval
		// attribute set dynamically:
		// _sContextPath: the context path for the PO currently displayed

		/* =========================================================== */
		/* Initialization                                              */
		/* =========================================================== */
		oJSONModel: new sap.ui.model.json.JSONModel(),
		onInit: function() {
			this._oApplication = this.getApplication();
			this._oApplication.registerDetailController(this);
			this._oItemsTable = this.byId("poItemsTable");
			this._oItemTemplate = this.byId("columnListItem").clone();
			this._initializeViewModel();
			this._oSubControllerForApproval = new SubControllerForApproval(this.getView(), this.getResourceBundle());
			var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrameColumn");
			var oPopOver = this.getView().byId("idPopOverColumn");
			oPopOver.connect(oVizFrame.getVizUid());
			var oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			var oRouter = oComponent.getRouter();
			oRouter.attachRouteMatched(this._onObjectMatched, this);
			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this.oArray = [{
				"text": "Purchase Order",
				"columnKey": "Purchase Order",
				"visible": true
			}, {
				"text": "Responsible Person",
				"columnKey": "Responsible Person",
				"visible": true
			}, {
				"text": "Order Value",
				"columnKey": "Order Value",
				"visible": true
			}, {
				"text": "Total Invoiced",
				"columnKey": "Total Invoiced",
				"visible": true
			}, {
				"text": "Obligo",
				"columnKey": "Obligo",
				"visible": true
			}, {
				"text": "cProject Amount",
				"columnKey": "cProject Amount",
				"visible": true
			}, {
				"text": "Delta Invocied cProject",
				"columnKey": "Delta Invocied cProject",
				"visible": true
			}];
			this.oJSONModel = new sap.ui.model.json.JSONModel(this.oArray);
		},
		_onObjectMatched: function(oEvent) {
			if (oEvent.getParameter("name") === "PurchaseOrderDetails") {
				this.getModel("flagModel").setProperty("/flag", false);
			}
		},

		_initializeViewModel: function() {
			/*	var that = this;
				jQuery.ajax("/webapp/test/PurchaseOrders.json", { // load the data from a relative URL (the Data.json file in the same directory)
					dataType: "json",
					success: function(data) {
					//if (xhr.status !== 304 ){	
						this._viewModel = new sap.ui.model.json.JSONModel(data);
						that.byId("idVizFrameColumn").setModel(this._viewModel);
						
					//}
					}
				});*/
			this._oViewModel = new JSONModel({
				dataLoaded: false, // Contains the information whether the data for the header area have been loaded
				//originalBusyDelayAttributesLayout: this.byId("attributesLayout").getBusyIndicatorDelay(),
				//originalBusyDelayItemsTable: this._oItemsTable.getBusyIndicatorDelay(),
				itemCount: -1 // Negative item count is used to suppress the display of the number of items
			});
			this.setModel(this._oViewModel, "viewProperties");
		},

		/* =========================================================== */
		/* Navigation                                                  */
		/* =========================================================== */

		// This method is called by the controller of the app when the user navigates to or away from this page.
		// In the first case, parameter sContextPath contains the context path for the PO to be displayed. In the second case,
		// sContextPath is faulty.
		setContextPath: function(sContextPath) {
			if (this._sContextPath === sContextPath) {
				return;
			}
			this._sContextPath = sContextPath;
			//	this._oViewModel.setProperty("/itemCount", -1); // remove number of PO items from display until the number has been evaluated again
			if (sContextPath) {
				this._bindView(sContextPath);
			} else {
				this.getView().unbindElement();
				this._oItemsTable.unbindItems();
			}
		},

		// Bind the header and the items to the context path
		_bindView: function(sPOPath) {
			this._oViewModel.setProperty("/dataLoaded", false);
			var oView = this.getView();
			var fnOnElementBindingCompleted = function(oEvent) {
				var oPurchaseOrder = this.getModel().getObject(oEvent.getSource().getPath());
				if (oEvent.getSource().getBoundContext()) {
					var oGlobalModel = this.getGlobalModel();
					oGlobalModel.setProperty("/detailImmediateBusy", false); // this property is only true for one turnaround
					this._oViewModel.setProperty("/dataLoaded", true);
					if (this._oViewModel.getProperty("/itemCount") >= 0) { // When items and header have been read, reset the
						oGlobalModel.setProperty("/isBusyApproving", false); // busy status that was potentially set by an approval step
					}
				} else {
					this._oApplication.showEmptyView("objectNotFound");
				}
				/**
				 * @ControllerHook Adaptation of purchase order details view
				 * This method is called after the data of the requested purchase order has been loaded to be shown on the detail view
				 * @callback nw.epm.refapps.ext.po.apv.controller.S3_PurchaseOrderDetails~extHookOnDataReceived
				 * @param {object} requested purchase order
				 * @return {void}
				 */
				if (this.extHookOnDataReceived) {
					this.extHookOnDataReceived(oPurchaseOrder);
				}
			}.bind(this);
			oView.bindElement({
				path: sPOPath,
				events: {
					change: fnOnElementBindingCompleted
				},
				parameters: {
					select: "POId,OrderedByName,SupplierName,GrossAmount,CurrencyCode,ChangedAt,DeliveryDateEarliest,LaterDelivDateExist,DeliveryAddress,ItemCount",
					groupId: "Header" // Retrieve header and item information with parallel calls because the header information might be faster
				}
			});
			// Note that items are NOT bound relative to the header, otherwise the retrieval of the items would be deferred
			// until the header data has been read.
			this._oItemsTable.bindItems({
				path: sPOPath + "/PurchaseOrderItems",
				parameters: {
					select: "POId,POItemPos,Product,Price,PriceCurrency,GrossAmount,GrossAmountCurrency,Quantity,DeliveryDate",
					groupId: "Header"
				},
				template: this._oItemTemplate
			});
		},

		filterGlobally: function(oEvent) {
			var sQuery = oEvent.getParameter("query");
			this._oGlobalFilter = null;
			if (sQuery) {
				this._oGlobalFilter = new Filter([
					new Filter("POId", FilterOperator.Contains, sQuery),
					new Filter("Product", FilterOperator.Contains, sQuery)
				], false);
			}

			this._filter();
		},

		_filter: function() {
			var oFilter = null;

			if (this._oGlobalFilter && this._oPriceFilter) {
				oFilter = new sap.ui.model.Filter([this._oGlobalFilter, this._oPriceFilter], true);
			} else if (this._oGlobalFilter) {
				oFilter = this._oGlobalFilter;
			} else if (this._oPriceFilter) {
				oFilter = this._oPriceFilter;
			}

			this.getView().byId("poItemsTable").getBinding("items").filter(oFilter, "Application");
		},
		onSettingsTable: function(oEvent) {
			var oPersonalizationDialog = sap.ui.xmlfragment("nw.epm.refapps.purchaseorders.approve.view.fragment.CustomeColumnDialog", this);
			//this.oJSONModel.setProperty("/ShowResetEnabled", this._isChangedSortItems() || this._isChangedColumnsItems());
			oPersonalizationDialog.setModel(this.oJSONModel);
			this.getView().addDependent(oPersonalizationDialog);
			this.oDataBeforeOpen = jQuery.extend(true, {}, this.oJSONModel.getData());
			oPersonalizationDialog.open();
		},

		onOK: function(oEvent) {
			var tableItems = oEvent.getParameters().payload.columns.tableItems;
			var tableColumnItems = this.byId("poItemsTable").getColumns();
			for (var i = 0; i < tableItems.length; i++) {
				for (var j = 0; j < tableColumnItems.length; j++) {
					if (tableItems[i].columnKey === tableColumnItems[j].getHeader().getText()) {
						if (tableItems[i].visible === false) {
							tableColumnItems[j].setVisible(false);
						} else {
							tableColumnItems[j].setVisible(true);
						}
					} else {
						continue;
					}
				}
			}
			oEvent.getSource().close();
		},
		onCancel: function(oEvent) {
			this.oJSONModel.setProperty("/", jQuery.extend(true, [], this.oDataBeforeOpen));
			this.oDataBeforeOpen = {};
			oEvent.getSource().close();
		},
		// Event handler for the table of PO items that is attached declaratively
		onItemsTableUpdateFinished: function(oEvent) {
			this._oViewModel.setProperty("/itemCount", oEvent.getParameter("total"));
			if (this._oViewModel.getProperty("/dataLoaded")) { // If header data are already loaded, reset the busy status
				this.getGlobalModel().setProperty("/isBusyApproving", false);
			}
		},

		onNavButtonPressed: function() {
			this._oApplication.navBack(true, true);
			this.setContextPath(); // detach from backend
		},

		_createDialog: function(sDialog) {
			var oDialog = sap.ui.xmlfragment(this.getView().getId(), sDialog, this);
			utilities.attachControlToView(oDialog);
			return oDialog;
		},

		/* =========================================================== */
		/* Button handlers attached declaratively                      */
		/* =========================================================== */

		onApprovePressed: function() {
			this._onOpenApprovalDialog(true);
		},

		onRejectPressed: function() {
			this._onOpenApprovalDialog(false);
		},

		onActionSheetPressed: function(oEvent) {
			if (!this._oActionSheet) {
				this._oActionSheet = this._createDialog("nw.epm.refapps.purchaseorders.approve.view.fragment.ActionSheet");
				this.getView().addDependent(this._oActionSheet);
			}
			this._oActionSheet.openBy(oEvent.getSource());
		},

		// Used by event handlesr for buttons 'Approve' and 'Reject'
		_onOpenApprovalDialog: function(bApprove) {
			if (this._oApplication.oApprover.isSwipeApproving(this.getGlobalModel().getProperty("/currentPOId"))) {
				return; // If the current PO is being approved using swipe anyway, ignore this redundant operation
			}
			// Open approval dialog. oWhenApprove is a Promise for the end of the whole process.
			var oWhenApproved = this._oSubControllerForApproval.openDialog(bApprove, [this.getModel().getProperty(this._sContextPath)]);
			if (Device.system.phone) { // On a phone, when the approval is really completed: go to master list
				oWhenApproved.then(function(bProcessed) { // bProcessed indicates whether the approval was really completed
					if (bProcessed) {
						this._oApplication.navBack(false, true); // go to master list 
						this.setContextPath(); // detach from backend
					}
				}.bind(this));
			}
		},

		onEmailPressed: function() {
			var oBindingContext = this.getView().getBindingContext(),
				oPurchaseOrder = oBindingContext.getObject(),
				oResourceBundle = this.getResourceBundle(),
				sSubject = oResourceBundle.getText("xtit.emailSubject", [oPurchaseOrder.POId]),
				sContent = oResourceBundle.getText("xtit.emailContent", [oPurchaseOrder.POId, oPurchaseOrder.SupplierName]);
			sap.m.URLHelper.triggerEmail(null, sSubject, sContent);
		},
		_showSummaryPage: function(oEvent) {
			var aTarget = ["detail", "summary"];
			this.getRouter().getTargets().display(aTarget);
			this.getRouter().navTo("InvoiceOrderDetails", {
				POId: oEvent.getSource().getBindingContext().getObject().POId,
				Obligo: oEvent.getSource().getBindingContext().getObject().Price
			});
		},
		fnNavToInoviceOrder: function(oEvent) {
			this._showSummaryPage(oEvent);
		}
	});
});