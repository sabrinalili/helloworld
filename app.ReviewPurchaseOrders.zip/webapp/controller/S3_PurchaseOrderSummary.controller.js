sap.ui.define([
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"nw/epm/refapps/purchaseorders/approve/controller/BaseController",
	"nw/epm/refapps/purchaseorders/approve/controller/SubControllerForApproval"
], function(Device, JSONModel, BaseController, SubControllerForApproval) {
	"use strict";

	return BaseController.extend("nw.epm.refapps.purchaseorders.approve.controller.S3_PurchaseOrderSummary", {
		// _oSubControllerForApproval is used to send the dialog for confirming the approval.
		onInit: function() {
			//sap.ui.getCore().byId("shell").getHeader().setLogo("");
			//sap.ui.getCore().byId("shell").getHeader().setShowLogo(false);
			this._oSubControllerForApproval = new SubControllerForApproval(this.getView(), this.getResourceBundle());
			//this.resourceBundle = this.getResourceBundle();
			//this.byId("header").setTitle(this.resourceBundle.getText("xtit.summaryHeaderTitle", this.getGlobalModel().getData().currentPOId));
			//this._initializeViewModel();
			var oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
            var oRouter = oComponent.getRouter();
            oRouter.attachRouteMatched(this._onObjectMatched, this);
            
            if (this.getModel("flagModel").getProperty("/flag")){
			var aTarget = ["detail", "master"];
			oRouter.getTargets().display(aTarget);
            	
            }
		/*	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var aTarget = ["detail", "summary"];
			oRouter.getTargets().display(aTarget);
			oRouter.getRoute("InvoiceOrderDetails").attachPatternMatched(this._onObjectMatched, this);*/

		/*	var oGlobalModel = this.getGlobalModel(),
				oSelectedBinding = oGlobalModel.bindProperty("/selectedPurchaseOrders"),
				oMultiSelectBinding = oGlobalModel.bindProperty("/isMultiSelect");
			oSelectedBinding.attachChange(this.onSelectedPOsChanged, this);
			oMultiSelectBinding.attachChange(this.onSelectedPOsChanged, this);
			this._iSimulationCount = 0;
			this.onSelectedPOsChanged();*/
		},
		_onObjectMatched: function(oEvent) {
			var that = this;
			if (oEvent.getParameter("name") === "InvoiceOrderDetails"){
				that.byId("detaildetailPage").setBusy(true);
		var obligoValue = oEvent.getParameter("arguments").Obligo;
		var POIdValue = oEvent.getParameter("arguments").POId;
		this.resourceBundle = this.getResourceBundle();
		this.byId("header").setTitle(this.resourceBundle.getText("xtit.summaryHeaderTitle", POIdValue));
		//var obligo = obligoValue
		this.byId("obligoId").setText(obligoValue);
		this._initializeViewModel(POIdValue);
		that.byId("detaildetailPage").setBusy(false);
			}
		},

		_initializeViewModel: function(POIdValue) {
			//this.byId("detaildetailPage").setBusy(true);
			var that = this;
			jQuery.ajax("./InvoiceOrderItems.json", { // load the data from a relative URL (the Data.json file in the same directory)
				dataType: "json",
				success: function(data) {
				//if (xhr.status !== 304 ){	
				    that.byId("purchaseOrderTable").setBusy(true);
					this._oViewModel = new sap.ui.model.json.JSONModel(data);
					var modelArrayLength = this._oViewModel.getData().length;
					var modelArray = [];
					var invoiceOrderModel = new JSONModel();
					for (var i = 0; i < modelArrayLength; i++) {
						if (this._oViewModel.getData()[i].POId === POIdValue) {
							modelArray.push(this._oViewModel.getData()[i]);
						}
					}
					invoiceOrderModel.setData(modelArray);
					that.setModel(invoiceOrderModel);
				//}
				that.byId("purchaseOrderTable").setBusy(false);
				}
			});
		
		},
		 formatStatusState: function(value) {
            var state = "";
            switch(value) {
            case "Approve":
                state = "Success";
                break;
            case "Cancel":
                state = "Error";
                break;
            default:
                state = "None";
            }
            return state;
        },

	/*	onSelectedPOsChanged: function() {
			var oGlobalModel = this.getGlobalModel();
			if (oGlobalModel.getProperty("/isMultiSelect")) {
				var aSelectedPOs = oGlobalModel.getProperty("/selectedPurchaseOrders"),
					sConcatenatedIds = "";
				for (var i = 0, sDelimiter = ""; i < aSelectedPOs.length; i++) {
					sConcatenatedIds = sConcatenatedIds + sDelimiter + aSelectedPOs[i].POId;
					sDelimiter = ",";
				}
				var oModel = this.getModel();
				this._iSimulationCount++;
				this._oViewModel.setProperty("/SimulateBudgetReduction", {});
				oModel.callFunction("/SimulateBudgetReduction", {
					method: "POST",
					urlParameters: {
						POIds: sConcatenatedIds
					},
					success: this.onSimulationUpdated.bind(this, this._iSimulationCount)
				});
			}
		},*/

	/*	onSimulationUpdated: function(iRequestSimulationCount, oResponse) {
			if (iRequestSimulationCount !== this._iSimulationCount) {
				return;
			}
			this._oViewModel.setProperty("/SimulateBudgetReduction", oResponse.SimulateBudgetReduction);
		},*/

	/*	onApprovePressed: function() {
			this._onOpenApprovalDialog(true);
		},

		onRejectPressed: function() {
			this._onOpenApprovalDialog(false);
		},

		// Used by event handler for buttons 'Approve' and 'Reject'
		_onOpenApprovalDialog: function(bApprove) {
			var oWhenIsApproved = this._oSubControllerForApproval.openDialog(bApprove, this.getModel("globalProperties").getProperty(
				"/selectedPurchaseOrders"));
			oWhenIsApproved.then(this.onApprovalEnded.bind(this));
		},*/

		// This event handler is called when an approve/reject action has ended.
		// Note that this may be either because the user decided to cancel the action or because the approval was successfully executed in the backend.
		// Parameter bProcessed is used to distinguish between these two situations.
	/*	onApprovalEnded: function(bProcessed) {
			if (bProcessed) {
				this.getGlobalModel().setProperty("/selectedPurchaseOrders", []);
				if (Device.system.phone) { // When the app is being used on a phone leave the detail screen and go back to the master list.
					this._navToMaster();
				}
			}
		},*/

		// Handler for the navigation button (only available when the app is being used on a phone) that is attached declaratively.
		onNavButtonPressed: function(oEvent) {
			this._navToPODetailPage(oEvent);
		},

		// Event handler is called after the items are updated in the summary table
		onTableUpdateFinished: function(oEvent) {
			/**
			 * @ControllerHook Adaptation of summary table
			 * This method is called after the data of the summary table has been updated due to selection or deselection of
			 * one of the purchase orders in the master list.
			 * @callback nw.epm.refapps.ext.po.apv.controller.S3_PurchaseOrderSummary~extHookOnTableUpdateFinished
			 * @param {sap.ui.base.Event} the 'updateFinished' event triggered by sap.m.Table control
			 * @return {void}
			 */
			if (this.extHookOnTableUpdateFinished) {
				this.extHookOnTableUpdateFinished(oEvent);
			}
		},
		// Navigate back to PO detail page.
		_navToPODetailPage: function() {
			var bReplace = !Device.system.phone,
				aTarget = ["detail", "master"];
			//oItem.setSelected(true);
			this.getRouter().getTargets().display(aTarget);
			this.getRouter().navTo("PurchaseOrderDetails", {
				POId: this.getGlobalModel().getData().currentPOId
			}, bReplace);
		}
	});
});