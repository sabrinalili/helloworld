sap.ui.define([
		"sap/ui/core/UIComponent",
		"./controller/Application",
		"sap/ui/model/json/JSONModel"
	], function(UIComponent, Application, JSONModel) {
	"use strict";
	
    /*
     *  This class represents the app. The lifecycle methods of this class are used by the
     *  Firoi Launchpad to start and stop the app.
     *  Note that this class delegates all programm logic to the ApplicationController.
     *  Hence, only the declarative configuration of the app can be found here.
     */

	return UIComponent.extend("nw.epm.refapps.purchaseorders.approve.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app.
		 * After having called the initialization routine of the super class the app specific
		 * initialization is delegated to the Application controller.
		 */
		init: function() {
			var hideIcon = setInterval(this.hide,500);
			 if(!$("#shell-header-icon").is(":visible")) {
            	clearInterval(hideIcon);
            }
			//sap.ui.getCore().byId("shell").getHeader().setLogo("");
			UIComponent.prototype.init.apply(this, arguments);
			//sabrina delete
			var oApplication = new Application(this);
			oApplication.init();
			this.getRouter().initialize();
			var oViewModel = new JSONModel({
				flag: true
			});
			this.setModel(oViewModel, "flagModel");
			 
            
           
			//sap.ui.getCore().byId("shell-header-icon").setVisible(false);
		},
		hide: function() {
			if($("#shell-header-icon").is(":visible")) {
				$("#shell-header-icon").hide();
			}
		} 
	});
});